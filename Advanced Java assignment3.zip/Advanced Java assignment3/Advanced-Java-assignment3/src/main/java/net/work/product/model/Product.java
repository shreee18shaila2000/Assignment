package net.work.product.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="products")
public class Product {
 
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="id")
    protected int id;
 
    @Column(name="title")
    protected String title;
 
    @Column(name="quantity")
    protected Integer quantity;
 
    @Column(name="size")
    protected Integer size;
    
    @Column(name="image")
    protected String image;
 
    public Product() {
    }
 
    public Product(String title, Integer quantity, Integer size, String image) {
        super();
        this.title = title;
        this.quantity = quantity;
        this.size = size;
        this.image = image;
    }

    public Product(int id, String title, Integer quantity, Integer size, String image) {
        super();
        this.id = id;
        this.title = title;
        this.quantity = quantity;
        this.size = size;
        this.image = image;
    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public Integer getQuantity() {
        return quantity;
    }
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
    public Integer getSize() {
        return size;
    }
    public void setSize(Integer size) {
        this.size = size;
    }
    public String getImage() {
        return image;
    }
    public void setImage(String image) {
        this.image = image;
    }
}
